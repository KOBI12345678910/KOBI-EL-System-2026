# ERP 2026 — Database Upload Report

- **Run**: 2026-04-16T08:49:22.086Z
- **Cluster**: `database\erp_main.pglite`
- **Migration files**: 33
- **Applied this run**: 0
- **Failed**: 33
- **Tables total**: 1

## Tables per schema

| Schema | Tables |
|---|---:|
| `public` | 1 |
| `governance` | 0 |
| `commercial` | 0 |
| `procurement` | 0 |
| `execution` | 0 |
| `inventory` | 0 |
| `workforce` | 0 |
| `finance` | 0 |
| `docs` | 0 |
| `comms` | 0 |
| `intelligence` | 0 |
| `analytics` | 0 |

## Migration results

| # | Version | Name | Status | Time |
|---:|---|---|---|---:|
| 1 | `00000` | master_schema | ❌ syntax error at or near "extension" | 5ms |
| 2 | `00001` | rls_helpers_and_policies | ❌ schema "governance" does not exist | 4ms |
| 3 | `00002` | secure_rpc_functions | ❌ syntax error at or near "supabase" | 2ms |
| 4 | `00003` | action_rpcs_and_state_machines | ❌ syntax error at or near "supabase" | 1ms |
| 5 | `00004` | rls_helper_functions_v2 | ❌ schema "governance" does not exist | 1ms |
| 6 | `00005` | rls_policies | ❌ schema "commercial" does not exist | 3ms |
| 7 | `00006` | read_models_and_360_rpcs | ❌ relation "finance.invoices" does not exist | 1ms |
| 8 | `00007` | performance_indexes | ❌ schema "governance" does not exist | 1ms |
| 9 | `00008` | idempotency_table | ❌ schema "governance" does not exist | 1ms |
| 10 | `00009` | seed_roles_permissions | ❌ relation "governance.roles" does not exist | 1ms |
| 11 | `00010` | enterprise_expansion_30_tables | ❌ schema "commercial" does not exist | 2ms |
| 12 | `00011` | enterprise_expansion_30_more_tables | ❌ schema "commercial" does not exist | 1ms |
| 13 | `00012` | rpc_functions_core_block | ❌ schema "commercial" does not exist | 1ms |
| 14 | `00013` | seed_role_permission_mapping | ❌ relation "governance.roles" does not exist | 7ms |
| 15 | `00014` | rls_policies_expansion_tables | ❌ schema "commercial" does not exist | 1ms |
| 16 | `00015` | read_model_views | ❌ relation "finance.invoices" does not exist | 1ms |
| 17 | `00016` | trigger_functions_computed_fields | ❌ schema "execution" does not exist | 2ms |
| 18 | `00017` | app_menu | ❌ duplicate key value violates unique constraint "app_menu_pkey" | 31ms |
| 19 | `00018` | rpc_control_rooms_and_360 | ❌ schema "analytics" does not exist | 0ms |
| 20 | `00019` | security_rls_core | ❌ schema "governance" does not exist | 2ms |
| 21 | `00020` | get_my_permissions_rpc | ❌ schema "governance" does not exist | 1ms |
| 22 | `00021` | dashboard_tables | ❌ schema "analytics" does not exist | 1ms |
| 23 | `00022` | dashboard_rpcs | ❌ schema "analytics" does not exist | 1ms |
| 24 | `00023` | ai_agent_registry_and_views | ❌ schema "intelligence" does not exist | 1ms |
| 25 | `00024` | orchestration_tables | ❌ schema "governance" does not exist | 44ms |
| 26 | `00025` | command_center_rpcs | ❌ relation "orchestration.workflow_runs" does not exist | 1ms |
| 27 | `00026` | control_room_rpcs | ❌ schema "analytics" does not exist | 12ms |
| 28 | `00027` | enterprise_30_tables | ❌ schema "governance" does not exist | 117ms |
| 29 | `00028` | routing_and_ai_rpcs | ❌ schema "routing" does not exist | 7ms |
| 30 | `00029` | enterprise_30_tables_rls | ❌ schema "governance" does not exist | 6ms |
| 31 | `00030` | enterprise_seed_data | ❌ relation "crm.leads" does not exist | 6ms |
| 32 | `00031` | analytics_views_and_rpcs | ❌ relation "crm.leads" does not exist | 18ms |
| 33 | `00032` | treasury_and_extra_routes | ❌ relation "treasury.bank_accounts" does not exist | 1ms |
